export { default as GetCategoryDetails } from "./GetCategoryDetails";
export { default as GetSupplierDetails } from "./GetSupplierDetails";
export { default as GetProductDetails } from "./GetProductDetails";
export { default as GetDashboardDetails } from "./GetDashboardDetails";
export { default as GetUserLogin } from "./GetUserLogin";
export { default as GetSalonDetails } from "./GetSalonDetails";
export { default as GetLocationDetails } from "./GetLocationDetails";
