var scheduler = {
    init: () => {
    },
}

export default scheduler;