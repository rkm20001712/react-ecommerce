module.exports = {
    prod_mode: true,
    db_host: 'localhost',
    db_user: 'root',
    db_password: '',
    api_base_url: 'http://localhost:4000',
}