import React from 'react';
import "./index.css"
const Nodata = () => {
    return (
        <div className="container">
            <div className="_1sHuca">
                <img className="img-fluid" src="/img/not-found-result.png" alt={404} />
                <div className="_3uTeW4">Sorry, no results found!</div>
                {/* <div className="CqJpD_">Please check the spelling or try searching for something else</div> */}
                </div>
        </div>
    );
};

export default Nodata;